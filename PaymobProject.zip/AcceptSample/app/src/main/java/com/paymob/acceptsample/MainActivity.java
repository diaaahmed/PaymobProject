package com.paymob.acceptsample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.paymob.acceptsdk.IntentConstants;
import com.paymob.acceptsdk.PayActivity;
import com.paymob.acceptsdk.PayActivityIntentKeys;
import com.paymob.acceptsdk.PayResponseKeys;
import com.paymob.acceptsdk.SaveCardResponseKeys;
import com.paymob.acceptsdk.ThreeDSecureWebViewActivty;
import com.paymob.acceptsdk.ToastMaker;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button1;
    Button button2;
    Button button3;

    // Arbitrary number and used only in this activity. Change it as you wish.
    static final int ACCEPT_PAYMENT_REQUEST = 10;

    // Replace this with your actual payment key
    final String paymentKey = "ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SjFjMlZ5WDJsa0lqbzRNVFEyT1RVc0ltRnRiM1Z1ZEY5alpXNTBjeUk2TWpBd01EQXNJbU4xY25KbGJtTjVJam9pUlVkUUlpd2lhVzUwWldkeVlYUnBiMjVmYVdRaU9qSTNOalUyTXpjc0ltOXlaR1Z5WDJsa0lqb3hNVEUwTVRZM01EZ3NJbUpwYkd4cGJtZGZaR0YwWVNJNmV5Sm1hWEp6ZEY5dVlXMWxJam9pUkdsaFlTSXNJbXhoYzNSZmJtRnRaU0k2SWtGb2JXVmtJaXdpYzNSeVpXVjBJam9pVGtFaUxDSmlkV2xzWkdsdVp5STZJazVCSWl3aVpteHZiM0lpT2lKT1FTSXNJbUZ3WVhKMGJXVnVkQ0k2SWs1Qklpd2lZMmwwZVNJNklrNUJJaXdpYzNSaGRHVWlPaUpPUVNJc0ltTnZkVzUwY25raU9pSk9RU0lzSW1WdFlXbHNJam9pWkdsaFlXRm9iV1ZrYURJd01FQm5iV0ZwYkM1amIyMGlMQ0p3YUc5dVpWOXVkVzFpWlhJaU9pSXdNVEF5T0RJek56STJOeUlzSW5CdmMzUmhiRjlqYjJSbElqb2lUa0VpTENKbGVIUnlZVjlrWlhOamNtbHdkR2x2YmlJNklrNUJJbjBzSW14dlkydGZiM0prWlhKZmQyaGxibDl3WVdsa0lqcDBjblZsTENKbGVIUnlZU0k2ZTMwc0luTnBibWRzWlY5d1lYbHRaVzUwWDJGMGRHVnRjSFFpT21aaGJITmxMQ0psZUhBaU9qRTJPREF6TmpZMk56VXNJbkJ0YTE5cGNDSTZJakU1Tnk0MU9TNHlPQzR4T1RraWZRLmNrWDdSUi0tTWx0eEFveVVKZ0EtYjZpcHUyUVJGZHNlRTB4WW9XR0RCUkJCUmlEN3JSeERCeWt5NkppSG5vMlpCMDE2dDFRYkM5Q0FvTXBGZEQ3T3RB";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.Button1);
        button1.setOnClickListener(this);
        button2 = findViewById(R.id.Button2);
        button2.setOnClickListener(this);
        button3 = findViewById(R.id.Button3);
        button3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.Button1:
                startPayActivityNoToken(true);
                break;
            case R.id.Button2:
                startPayActivityNoToken(false);
                break;
            case R.id.Button3:
                startPayActivityToken();
                break;
        }
    }

    private void startPayActivityNoToken(Boolean showSaveCard)
    {
        Intent pay_intent = new Intent(this, PayActivity.class);
        putNormalExtras(pay_intent);
        pay_intent.putExtra(PayActivityIntentKeys.SAVE_CARD_DEFAULT, false);
        pay_intent.putExtra(PayActivityIntentKeys.SHOW_SAVE_CARD, showSaveCard);
        pay_intent.putExtra(PayActivityIntentKeys.THEME_COLOR,getResources().getColor(R.color.ThemeColor));
        pay_intent.putExtra("ActionBar",true);
        pay_intent.putExtra("language","ar");
        startActivityForResult(pay_intent, ACCEPT_PAYMENT_REQUEST);
        Intent secure_intent = new Intent(this, ThreeDSecureWebViewActivty.class);
        secure_intent.putExtra("ActionBar",true);
    }

    private void startPayActivityToken() {
        Intent pay_intent = new Intent(this, PayActivity.class);

        putNormalExtras(pay_intent);
        // replace this with your actual card token
        pay_intent.putExtra("language","ar");
        pay_intent.putExtra(PayActivityIntentKeys.TOKEN, "6088c38c19705a495f1727561d4f4814b2ed7e45e9cd80c72f233253");
        pay_intent.putExtra(PayActivityIntentKeys.MASKED_PAN_NUMBER, "xxxx-xxxx-xxxx-1234");
        pay_intent.putExtra(PayActivityIntentKeys.SAVE_CARD_DEFAULT, false);
        pay_intent.putExtra(PayActivityIntentKeys.SHOW_SAVE_CARD, false);
        pay_intent.putExtra("ActionBar",true);
        pay_intent.putExtra(PayActivityIntentKeys.THEME_COLOR,getResources().getColor(R.color.ThemeColor));

        pay_intent.putExtra( PayActivityIntentKeys.FIRST_NAME, "Cliffo");
        pay_intent.putExtra(PayActivityIntentKeys.LAST_NAME, "Nicol");
        pay_intent.putExtra(PayActivityIntentKeys.BUILDING,"8028");
        pay_intent.putExtra(PayActivityIntentKeys.FLOOR, "42");
        pay_intent.putExtra(PayActivityIntentKeys.APARTMENT, "803");
        pay_intent.putExtra(PayActivityIntentKeys.CITY, "Jask");
        pay_intent.putExtra(PayActivityIntentKeys.STATE, "Uta");
        pay_intent.putExtra(PayActivityIntentKeys.COUNTRY,"CR" );
        pay_intent.putExtra(PayActivityIntentKeys.EMAIL, "claudette09@exa.com");
        pay_intent.putExtra(PayActivityIntentKeys.PHONE_NUMBER, "+86(8)9135210487");
        pay_intent.putExtra(PayActivityIntentKeys.POSTAL_CODE,  "01898");


        startActivityForResult(pay_intent, ACCEPT_PAYMENT_REQUEST);
    }

    private void putNormalExtras(Intent intent) {
        intent.putExtra(PayActivityIntentKeys.PAYMENT_KEY, paymentKey);
        intent.putExtra(PayActivityIntentKeys.THREE_D_SECURE_ACTIVITY_TITLE, "Verification");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Bundle extras = data.getExtras();

        if (requestCode == ACCEPT_PAYMENT_REQUEST) {

            if (resultCode == IntentConstants.USER_CANCELED)
            {
                // User canceled and did no payment request was fired
                ToastMaker.displayShortToast(this, "User canceled!!");
            } else if (resultCode == IntentConstants.MISSING_ARGUMENT) {
                // You forgot to pass an important key-value pair in the intent's extras
                ToastMaker.displayShortToast(this, "Missing Argument == " + extras.getString(IntentConstants.MISSING_ARGUMENT_VALUE));
            } else if (resultCode == IntentConstants.TRANSACTION_ERROR) {
                // An error occurred while handling an API's response
                ToastMaker.displayShortToast(this, "Reason == " + extras.getString(IntentConstants.TRANSACTION_ERROR_REASON));
            } else if (resultCode == IntentConstants.TRANSACTION_REJECTED) {
                // User attempted to pay but their transaction was rejected

                Toast.makeText(this, "REJECTED", Toast.LENGTH_SHORT).show();
                // Use the static keys declared in PayResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(this, extras.getString(PayResponseKeys.DATA_MESSAGE));
            } else if (resultCode == IntentConstants.TRANSACTION_REJECTED_PARSING_ISSUE) {
                // User attempted to pay but their transaction was rejected. An error occured while reading the returned JSON
                ToastMaker.displayShortToast(this, extras.getString(IntentConstants.RAW_PAY_RESPONSE));
            } else if (resultCode == IntentConstants.TRANSACTION_SUCCESSFUL) {
                // User finished their payment successfully
                Toast.makeText(this, "SUCCESS", Toast.LENGTH_SHORT).show();

                // Use the static keys declared in PayResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(this, extras.getString(PayResponseKeys.DATA_MESSAGE));
            } else if (resultCode == IntentConstants.TRANSACTION_SUCCESSFUL_PARSING_ISSUE) {
                // User finished their payment successfully. An error occured while reading the returned JSON.
                ToastMaker.displayShortToast(this, "TRANSACTION_SUCCESSFUL - Parsing Issue");

                // ToastMaker.displayShortToast(this, extras.getString(IntentConstants.RAW_PAY_RESPONSE));
            } else if (resultCode == IntentConstants.TRANSACTION_SUCCESSFUL_CARD_SAVED) {
                // User finished their payment successfully and card was saved.
                Toast.makeText(this, "SUCCESS CARD SAVE", Toast.LENGTH_SHORT).show();

                // Use the static keys declared in PayResponseKeys to extract the fields you want
                // Use the static keys declared in SaveCardResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(this, "Token == " + extras.getString(SaveCardResponseKeys.TOKEN));
            } else if (resultCode == IntentConstants.USER_CANCELED_3D_SECURE_VERIFICATION) {
                ToastMaker.displayShortToast(this, "User canceled 3-d scure verification!!");

                // Note that a payment process was attempted. You can extract the original returned values
                // Use the static keys declared in PayResponseKeys to extract the fields you want
                ToastMaker.displayShortToast(this, extras.getString(PayResponseKeys.PENDING));
            } else if (resultCode == IntentConstants.USER_CANCELED_3D_SECURE_VERIFICATION_PARSING_ISSUE) {
                ToastMaker.displayShortToast(this, "User canceled 3-d scure verification - Parsing Issue!!");

                // Note that a payment process was attempted.
                // User finished their payment successfully. An error occured while reading the returned JSON.
                ToastMaker.displayShortToast(this, extras.getString(IntentConstants.RAW_PAY_RESPONSE));
            }
        }
    }
}
